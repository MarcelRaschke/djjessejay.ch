DJ JESSE JAY — PRESSKIT

Contents:
- DJ-Jesse-Jay.jpg        Professional press photo (77 KB)
- biography-de.txt        Biography (German)
- biography-en.txt        Biography (English)
- biography-fr.txt        Biography (French)
- biography-it.txt        Biography (Italian)

Usage:
The photo and biography text are free to use for press coverage, radio
features, event promotion, and promotional materials when referencing DJ Jesse Jay.

For higher-resolution assets, additional photos, or special requests,
please get in touch via the contact form at https://djjessejay.ch/.

Links:
- Website: https://djjessejay.ch
- Radio LoRa: lora.ch (The Blue Dimension, every Thursday 00:00–06:00)
- SoundCloud: https://soundcloud.com/jessejay

---
Last updated: August 2026
